package com.dji.sdk.sample.internal;

public interface SeekBarValueChangeListener {
    void onValueChange(int val1, int val2);
}
