package com.dji.sdk.sample.internal;

public interface PickerValueChangeListener {
    void onValueChange(int pos1, int pos2);
}
